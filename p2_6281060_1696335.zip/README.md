Stop-and-Wait-Protocol
======================

C++ project emulating the stop and wait protocol.  (Concordia Computer Networking project)
